document.getElementById("signup-form").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const phone = document.getElementById("phone").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  // عملية التسجيل (تخزين البيانات محليًا كمثال)
  localStorage.setItem("user", JSON.stringify({ name, phone, email, password }));
  alert("تم إنشاء الحساب بنجاح!");
});